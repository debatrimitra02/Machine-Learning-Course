readme

%   Function to do Bayesian linear regression

Usage:
	CALL_bayesian_regression

# All derivations in png files